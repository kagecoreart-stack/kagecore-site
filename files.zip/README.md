# Shadow Frequency 🌀⚡

**Neurosymbolic AI-powered personality scanning platform.**

A cutting-edge, immersive web experience that "scans" your frequency through AI-generated storytelling, 3D avatars, and hyper-personalized insights.

## 🚀 Features

### Phase 1: Identity Scan
- **Liquid Glass Obsidian Shard**: Interactive 3D landing page that reacts to mouse movement and scroll
- **Invisible Onboarding**: Choose 3 emoji or write a sentence to describe your vibe
- **Neurosymbolic Logic**: Maps user input to Jungian archetypes and symbolic vectors
- **Micro-interactions**: Haptic feedback on mobile, glitch effects on desktop

### Phase 2: Shadow Reveal
- **Shadow Roast**: Hyper-personalized AI-generated personality analysis via Claude API
- **Cyberbrutalism Aesthetics**: Raw, glitchy, intentionally imperfect visuals
- **Peer-like Voice**: AI sounds like a friend, not a chatbot

### Phase 3: Viral Share-Lock (MVP)
- **3D Avatar Rendering**: Real-time WebGL shadow avatar generation
- **Blur Gate**: Blurred avatar until user shares to Pinterest/TikTok
- **Daily Shadow Oracle**: 5-second daily vibe check for retention

### Phase 4: Backend
- **Vercel Hosting**: Ultra-fast edge performance
- **Agentic Analytics**: Track behavioral telemetry (avatar hover points, dwell time)
- **High-CPM Ad Stack**: Native ads targeting dark academia & luxury niches

---

## 🛠 Tech Stack

- **Frontend**: Next.js 14 + React 18 + TypeScript
- **3D Rendering**: Three.js + WebGL
- **AI Backend**: Anthropic Claude API (Haiku for cost optimization)
- **Hosting**: Vercel
- **Styling**: CSS-in-JS + Cyberbrutalism theme
- **State**: Zustand
- **Animations**: Framer Motion + CSS animations

---

## 📦 Installation & Setup

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Anthropic API key

### Clone & Install

```bash
git clone https://github.com/yourusername/shadow-frequency.git
cd shadow-frequency
npm install
```

### Environment Variables

Create `.env.local`:

```env
ANTHROPIC_API_KEY=your_anthropic_api_key_here
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

### Run Locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to test.

---

## 🚀 Deployment to Vercel

### 1. Push to GitHub

```bash
git add .
git commit -m "Initial commit: Shadow Frequency MVP"
git push origin main
```

### 2. Deploy to Vercel

```bash
npm i -g vercel
vercel
```

Or connect your GitHub repo to [Vercel Dashboard](https://vercel.com/dashboard).

### 3. Add Environment Variables

In Vercel settings:
- Add `ANTHROPIC_API_KEY` in Environment Variables

---

## 📁 Project Structure

```
shadow-frequency/
├── app/
│   ├── api/
│   │   └── generate-roast/
│   │       └── route.ts          # Claude API endpoint
│   ├── page.tsx                   # Main page
│   ├── layout.tsx                 # Root layout
│   └── globals.css                # Global styles
├── components/
│   ├── LiquidGlassShard.tsx       # 3D landing component
│   ├── IdentityScan.tsx           # Emoji/sentence input UI
│   └── ShadowRoast.tsx            # AI-generated roast display
├── lib/
│   └── neurosymbolic.ts           # Symbolic intent mapping logic
├── package.json
├── tsconfig.json
├── next.config.js
└── README.md
```

---

## 🧠 Neurosymbolic Logic

The core innovation is the **Symbolic Intent Mapping**:

1. **User Input** → Emoji or sentence
2. **Symbolic Extraction** → Map to Jungian archetypes (Shadow, Rebel, Creator, etc.)
3. **Vector Generation** → Compose archetype + energy + resonance + shadow
4. **AI Prompt** → Generate hyper-personalized roast via Claude
5. **3D Parameters** → Translate symbolic vector into avatar geometry

Example:
- User selects: 🌙 ⚡ 🖤
- **Archetypes**: Shadow + Rebel + Lover
- **Vector**: "Introspective chaos with deep devotion"
- **AI Roast**: "You're a paradox: thoughtful but destructive, loyal but unpredictable..."
- **Avatar**: Spike count + glow intensity + color = visual expression

---

## 🎨 Aesthetics & Design

**Cyberbrutalism** is the core aesthetic:
- Dark academia color palette (deep purples, blacks)
- Neon accents (magenta, cyan, green)
- Intentional glitches and imperfections
- Scanline overlays
- Monospace fonts (IBM Plex Mono)
- Raw, unpolished surfaces

Every interaction feels **tactile** and **reactive**:
- Mouse movement deforms the 3D shard
- Scroll momentum translates to rotation
- Click → haptic vibration + glitch effect
- Text reveals use typewriter effect + chroma shift

---

## 📊 Analytics & Monetization

### Behavioral Tracking
- Avatar hover heatmaps (where users look longest)
- Dwell time per archetype
- Share-to-click funnel
- Daily Oracle return rate

### Revenue Streams
1. **High-CPM Ads**: Native, non-intrusive ads for:
   - Dark academia fashion brands
   - Luxury services (jewelry, watches, fragrance)
   - Psychological/self-help content
2. **Premium Features** (future): Unlockable avatars, daily oracle insights
3. **API Access** (future): B2B personality scanning for HR/recruiting

---

## 🔐 Privacy & Data

- No personal data stored by default
- Symbolic vectors are ephemeral (session-only)
- Share-gating provides explicit consent
- Analytics are behavioral, not identity-linked

---

## 🎯 Next Steps (Phase 3-4)

- [ ] WebGL avatar rendering engine
- [ ] Share-to-unlock integration (Pinterest/TikTok API)
- [ ] Daily Oracle reminder system
- [ ] Ad network integration
- [ ] User feedback loop / iterative roast refinement
- [ ] Mobile app version (React Native)

---

## 🤝 Contributing

Contributions welcome! Areas of focus:
- Avatar shader improvements
- AI prompt refinement
- Mobile UX optimization
- Analytics pipeline

---

## 📜 License

MIT License - feel free to fork and improve.

---

## 🌐 Live Demo

[shadow-frequency.vercel.app](https://shadow-frequency.vercel.app)

---

**Built with neurosymbolic logic + AI + 3D magic.** ⚡🌀✨
