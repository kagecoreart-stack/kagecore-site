# 🚀 Shadow Frequency - Quick Start Guide

## 5-Minute Setup

### Step 1: Clone & Install
```bash
git clone https://github.com/yourusername/shadow-frequency.git
cd shadow-frequency
npm install
```

### Step 2: Environment Variables
Create `.env.local`:
```env
ANTHROPIC_API_KEY=sk-ant-xxxxx
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

Get your API key: [console.anthropic.com](https://console.anthropic.com)

### Step 3: Run Locally
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## 🎯 Project Structure

```
shadow-frequency/
├── app/
│   ├── api/
│   │   ├── generate-roast/        # Claude API for personality analysis
│   │   ├── generate-oracle/       # Daily vibe check generation
│   │   └── analytics/             # Event tracking
│   ├── page.tsx                   # Main entry point
│   ├── layout.tsx                 # Root layout
│   └── globals.css                # Theme & animations
├── components/
│   ├── LiquidGlassShard.tsx       # 3D interactive landing (Three.js)
│   ├── IdentityScan.tsx           # Emoji/text input UI
│   ├── ShadowRoast.tsx            # AI personality display
│   ├── ShadowAvatar.tsx           # 3D avatar + blur gate
│   └── DailyShadowOracle.tsx      # Retention ritual
├── lib/
│   ├── neurosymbolic.ts           # Symbolic intent mapping (core brain)
│   ├── analytics.ts               # Behavioral tracking
│   └── ads.ts                     # Native ad integration
├── package.json
├── tsconfig.json
├── next.config.js
└── vercel.json
```

---

## 🧠 How It Works

### 1. **Neurosymbolic Logic** (the secret sauce)
```typescript
// User picks 3 emoji: 🌙 ⚡ 🖤
// ↓
// Maps to Jungian archetypes (Shadow + Rebel + Lover)
// ↓
// Generates symbolic vector (archetype, energy, resonance, shadow)
// ↓
// Claude API generates hyper-personalized "roast"
// ↓
// 3D avatar geometry shaped by symbolic vector
```

### 2. **Three Phases of Engagement**

**Phase 1: Identity Scan**
- User interacts with liquid glass shard (mouse movement)
- Selects 3 emoji OR writes 1 sentence
- Invisible onboarding (no forms, no pressure)

**Phase 2: Shadow Reveal**
- Claude API generates witty, peer-like personality analysis
- Uses cyberbrutalism language ("frequency", "glitch", "static")
- Typewriter effect + glitch animations

**Phase 3: Avatar + Viral Gate**
- Real-time 3D WebGL avatar
- Blurred until user shares to Pinterest/TikTok
- Share unlocks full resolution

**Phase 4: Daily Ritual**
- 5-second oracle reading each day
- Builds streak (retention metric)
- Stable ad revenue from returning users

---

## 📊 Key Metrics to Track

### Funnel
```
Landing (100%) 
  ↓
Identity Scan (70% attempt)
  ↓
Roast Generated (90% success)
  ↓
Avatar Viewed (95% view)
  ↓
Share Gate (40% share → unlock)
  ↓
Daily Return (25% next day)
```

### Business
- **CPM**: $15-30 (niche dark academia audience)
- **Monthly Revenue**: (daily users × 0.5 ads/session) × $0.02 CPM
  - 1,000 daily users = ~$300/month
  - 10,000 daily users = ~$3,000/month

---

## 🔧 Customization Points

### 1. Change Archetypes
Edit `lib/neurosymbolic.ts`:
```typescript
const EMOJI_ARCHETYPES = {
  "🌙": { archetype: "The Shadow", ... },
  // Add more emojis here
}
```

### 2. Tweak Colors (Cyberbrutalism Theme)
Edit `app/globals.css`:
```css
:root {
  --color-neon-green: #00ff88;     /* Change green */
  --color-neon-magenta: #ff00ff;   /* Change magenta */
  --color-neon-cyan: #00ccff;      /* Change cyan */
}
```

### 3. Adjust Share Gate
Edit `components/ShadowAvatar.tsx`:
```typescript
if (shareCount >= 1) {  // Change to >= 2 for 2 shares
  setIsBlurred(false);
}
```

### 4. Add Custom Ads
Edit `lib/ads.ts` → `mockAds` array

---

## 📈 Deployment Checklist

- [ ] Get Anthropic API key
- [ ] Push to GitHub
- [ ] Create Vercel account
- [ ] Connect GitHub repo to Vercel
- [ ] Add `ANTHROPIC_API_KEY` env var in Vercel
- [ ] Deploy (auto-triggers on push)
- [ ] Test on mobile
- [ ] Monitor analytics dashboard
- [ ] Set up email notifications for errors

---

## 🐛 Troubleshooting

### "Claude API key not found"
- Check `.env.local` is in root
- Verify API key is correct
- In Vercel, add env var to project settings

### "3D shard not rendering"
- Check browser console for Three.js errors
- Ensure WebGL is enabled
- Try `npm run build` locally first

### "Emoji not mapping to archetype"
- Add emoji to `EMOJI_ARCHETYPES` in `lib/neurosymbolic.ts`
- Each emoji needs archetype + energy + resonance + shadow

### "Performance slow"
- Check network tab (Claude API calls)
- Use Claude Haiku (fast) instead of Opus
- Enable Vercel Analytics
- Add Redis caching for oracle messages

---

## 🎨 Design System

### Typography
- **Display**: IBM Plex Mono Bold
- **Body**: IBM Plex Mono Regular

### Colors (Cyberbrutalism)
- **Dark BG**: #0a0e27
- **Neon Green**: #00ff88 (success, highlight)
- **Neon Magenta**: #ff00ff (danger, attention)
- **Neon Cyan**: #00ccff (info, secondary)

### Interactions
- Click → haptic vibration (mobile) or glitch (desktop)
- Hover → scale + glow
- Scroll → avatar rotation + particles

---

## 📚 Next Features (Roadmap)

**Phase 5: Community**
- User gallery of avatars
- Archetype matchmaking
- Collaborative roasts

**Phase 6: Monetization**
- Premium archetype packs
- NFT avatars
- API access for B2B

**Phase 7: Scale**
- Mobile app (React Native)
- AR avatar in physical world
- Voice input ("describe your vibe")

---

## 💡 Pro Tips

1. **Test on Mobile First**: Most users will be on phone
2. **Monitor Share Funnel**: This is your growth lever
3. **A/B Test Emoji**: Which ones convert best?
4. **Daily Oracle ROI**: Returning users = stable ad revenue
5. **Archetype Feedback**: Ask users if roast is accurate

---

## 🤝 Community & Support

- **Discord**: [Join the server](#)
- **Discussions**: [GitHub Discussions](#)
- **Issues**: Report bugs on GitHub
- **PRs**: Contributions welcome!

---

## 📝 License

MIT - Build on top of this freely!

---

**Ship it. Get feedback. Iterate. 🚀**
